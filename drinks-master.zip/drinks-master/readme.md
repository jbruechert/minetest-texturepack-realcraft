This mod aims to add more drinks to the world, and be easily expanded to support other mods that have fruits and veggies.

There is optional support for the thirsty mod, if you have it installed drinking juices will fill your hydration.
